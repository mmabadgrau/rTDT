
#ifndef __Excep__
#define __Excep__

using namespace std;


class NullNode {
public:
        void PrintMessage() {
                cout << "\nTrying to reach a null node (pointer == NULL).\n";
		exit(1);
	}
};

class MultiAllelic {
public:
        void PrintMessage() {
                cout << "\nThere are Multiallelic SNPs.\n";
		exit(1);
	}
};

class NoMemory {
public:
        void PrintMessage() {
                cout << "\nNot enough memory.\n";
		exit(1);
	}
};


class BadSize {
public:
        void PrintMessage() {
                cout << "\nDifferent size.\n";
		exit(1);
	}
};

class BadFile {
public:
        void PrintMessage() {
                cout << "\nIncorrect file format.\n";
		exit(1);
	}
};

class ErrorFile {
public:
        void PrintMessage() {
                cout << "\nFile does not exist or is damaged.\n";
		exit(1);
	}
};

class EmptyFile {
public:
        void PrintMessage() {
                cout << "\nFile does not have data.\n";
		exit(1);
	}
};


class IncorrectParameters {
public:
        void PrintMessage() {
                cout << "\nEspecified number of individuals y/or number of SNPs do not match with those in the file.\n";
		exit(1);
	}
};




#endif
